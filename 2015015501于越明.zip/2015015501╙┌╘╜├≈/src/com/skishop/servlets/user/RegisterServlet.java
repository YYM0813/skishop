package com.skishop.servlets.user;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.skishop.dao.user.UserDao;
import com.skishop.entity.User;

public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//1 获取参数
		String lastname = request.getParameter("lastname");
		String firstname = request.getParameter("firstname");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String surePassword = request.getParameter("surePassword");
		
			
		//2 实现
		if((password!=" ")&&(password.equals(surePassword))){
			User u = new User();
			u.setLastname(lastname);
			u.setFirstname(firstname);
			u.setEmail(email);
			u.setPassword(password);
			u.setSurePassword(surePassword);
			
			UserDao ud = new UserDao();
			ud.addUser(u);
			request.getRequestDispatcher("UserCenter.jsp").forward(request, response);
		}else{
			response.getWriter().print("error");
		}	
	}
}
