package com.skishop.servlets.product;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.skishop.dao.product.ProductColorDao;
import com.skishop.dao.product.ProductDao;
import com.skishop.dao.product.ProductTypeDao;
import com.skishop.entity.Product;
import com.skishop.entity.ProductColor;
import com.skishop.entity.productType;

/**
 * Servlet implementation class ProductAddServlet
 */
@WebServlet("/addProduct")
public class ProductAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProductAddServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ProductTypeDao ptd = new ProductTypeDao();
		List<productType> list = ptd.findAll();
		request.setAttribute("pt", list);
		request.getRequestDispatcher("addProduct.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 创建基础文件项目
		String name = " ";
		String color = " ";
		String pt = " ";
		String path = " ";
		int id = 0;

		FileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload upload = new ServletFileUpload(factory);
		try {
			List<FileItem> items = upload.parseRequest(request);
			for (FileItem fi : items) {
				if (fi.isFormField()) {
					if (fi.getFieldName().equals("pt"))
						pt =fi.getString("utf-8");
					if (fi.getFieldName().equals("id"))
						id = Integer.parseInt(fi.getString());
					if (fi.getFieldName().equals("name"))
						name = fi.getString("utf-8");
					if (fi.getFieldName().equals("color"))
						color = fi.getString("utf-8");
				} else {
					String itemPath = this.getServletContext().getRealPath("/upload");
					File dir = new File(itemPath);
					if (!dir.exists()) {
						dir.mkdir();
					}
					String extName = fi.getName().substring(fi.getName().lastIndexOf("."), fi.getName().length());
					String fileName = new Date().getTime() + extName;
					fi.write(new File(itemPath + "/" + fileName));
					path = "upload/" + fileName;
				}
			}
		} catch (FileUploadException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		// 向实体中保存数据
		Product p = new Product();
		p.setProductTypeId(Integer.parseInt(pt));
		p.setId(id);
		p.setName(name);
		p.setListimg(path);
		// 插入数据库
		ProductDao pd = new ProductDao();
		pd.AddProduct(p);
				
		String colors[]=color.split(",");
		ProductColor pc = new ProductColor();
		pc.setId(id);
		ProductColorDao pcd=new ProductColorDao();
		for(String c:colors){
			pc.setColorName(c);
			pcd.addColor(pc);
		}
	}
}
