package com.skishop.servlets.cart;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.skishop.dao.product.ProductDao;
import com.skishop.entity.CartItem;
import com.skishop.entity.Product;
import com.skishop.service.Cart;

/**
 * Servlet implementation class CartDeleteServlet
 */
@WebServlet("/cartdelete")
public class CartDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CartDeleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
		List<Product> list = new ArrayList<Product>();
		List<CartItem> cartlist = new ArrayList<CartItem>();
		
		int count = Integer.parseInt(request.getParameter("count"));
		int id = Integer.parseInt(request.getParameter("id"));
		count = count-1;		
		
		HttpSession session = request.getSession();
		Cart cart = (Cart) session.getAttribute("cart");
		Iterator i=cart.container.values().iterator();
		
		while(i.hasNext()){
			CartItem ci=(CartItem)i.next();
			if(ci.getProduct().getId()==id){
				if(count >= 0){
					ci.setCount(count);
				}
				else{
					ci.setCount(0);
				}
			}
			cartlist.add(ci);		
		}		
		session.setAttribute("cartItem", cartlist);
		request.getRequestDispatcher("checkout.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
