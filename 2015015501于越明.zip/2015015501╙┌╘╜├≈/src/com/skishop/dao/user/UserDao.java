package com.skishop.dao.user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.skishop.dao.BaseDao;
import com.skishop.entity.User;

public class UserDao {
	//查询用户信息
	public List<User> findUser(){
		List<User> list=new ArrayList<User>();
		Connection con=BaseDao.getCon();
		try {
			PreparedStatement pstm = con.prepareStatement("select * from user");
			ResultSet rs=pstm.executeQuery();
			while(rs.next()){
				User user = new User();
				user.setLastname(rs.getString(1));
				user.setFirstname(rs.getString(2));
				user.setEmail(rs.getString(3));
				user.setPassword(rs.getString(4));
				user.setSurePassword(rs.getString(5));
				list.add(user);
			}
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/*
	 * 新增用户
	 * */
	public static void addUser(User u){
		Connection con = BaseDao.getCon();
		try {     
			PreparedStatement pstm = con.prepareStatement("insert into user(lastname,firstname,email,password,surePassword)values(?,?,?,?,?)");
			pstm.setString(1, u.getLastname());
			pstm.setString(2, u.getFirstname());
			pstm.setString(3, u.getEmail());
			pstm.setString(4, u.getPassword());
			pstm.setString(5, u.getSurePassword());
			
			pstm.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	