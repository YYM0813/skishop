package com.skishop.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class BaseDao {
	static{
		//连接数据库
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	public static Connection getCon(){
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/ski_db?useUnicode=true&characterEncoding=UTF-8","root","");
			return con;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}		
	}
}
