package com.skishop.dao.product;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.skishop.dao.BaseDao;
import com.skishop.entity.ProductColor;

public class ProductColorDao {
	/*
	 * 修改颜色
	 * */
	public void updateColor(ProductColor pc){
		try{
			Connection con=BaseDao.getCon();
			PreparedStatement pstm=con.prepareStatement("update productcolor set colorName=? where id=?");
			pstm.setString(1, pc.getColorName());
			pstm.setInt(2, pc.getId());
			pstm.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}
	}	 
	 
	 
	/*
	 * 新增颜色
	 * */
	public void addColor(ProductColor pc){
		try{
			Connection con=BaseDao.getCon();
			PreparedStatement pstm=con.prepareStatement("insert into productcolor(colorname,id) values(?,?)");
			pstm.setString(1, pc.getColorName());
			pstm.setInt(2, pc.getId());
			pstm.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}

