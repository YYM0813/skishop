package com.skishop.dao.product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.skishop.dao.BaseDao;
import com.skishop.entity.Product;
import com.skishop.entity.productType;

public class ProductTypeDao {
	public List<productType> findAll(){
		try{
			List<productType> list=new ArrayList<productType>();
			Connection con=BaseDao.getCon();
			PreparedStatement pstm=con.prepareStatement("select * from producttype");
			ResultSet rs=pstm.executeQuery();
			while(rs.next()){
				productType pt=new productType();
				pt.setId(rs.getInt(1));
				pt.setName(rs.getString(2));
				list.add(pt);
			}
			return list;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
}
